﻿using System;

namespace PD
{
    class Program
    {
        static int ZnajdzMax(int[] tablica)
        {
            if (tablica.Length == 0)
            {
                return 0;
            }
            int max = tablica[0];
            for (int i = 0; i < tablica.Length; i++)
            {
                if (max < tablica[i])
                {
                    max = tablica[i];
                }
            }
            return max;
        }
        static uint A1(int[] tablica)
        {
            uint licznik = 0;
            for (int i = 0; i < tablica.Length; i++)
            {
                if (tablica[i] >= (ZnajdzMax(tablica) / 2))
                {
                    licznik++;
                }
            }
            return licznik;
        }
        static ulong A2(uint[] T, uint i = 0)
        {
            if (T.Length == 0 || T.Length == 1)
            {
                return 0;
            }
            else if (i == T.Length)
            {
                return 1;
            }
            return 0;
                                 
        }
        static char naMale(char c)
        {
            if (c >= 'A' && c <= 'Z')
            {
                return Convert.ToChar(c + 32);
            }
            return c;
        }        
        static bool CzySamogloska(char c)
        {
            if(c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'y' || c == 'u' || c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'Y' || c == 'U')
            {
                return true;
            }
            return false;
        }
        static bool CzySpolgloska(char c)
        {
            if (c == 'b' || c == 'c' || c == 'd' || c == 'f' || c == 'g' || c == 'h' || c == 'j' || c == 'k' || c == 'l' || c == 'm' || c == 'n' || c == 'U' || c == 'p' || c == 'r' || c == 's' || c == 't' || c == 'w' || c == 'x' || c == 'z' || c == 'B' || c == 'C' || c == 'D' || c == 'F' || c == 'G' || c == 'H' || c == 'J' || c == 'K' || c == 'L' || c == 'M' || c == 'N' || c == 'O' || c == 'P' || c == 'R' || c == 'S' || c == 'T' || c == 'W' || c == 'X' || c == 'Z')
            {
                return true;
            }
            return false;

        }
        static uint A3(string napis)
        {
            uint licznik = 0;
            for (int i = 0; i < napis.Length - 1; i++)
            {
                if (CzySamogloska(naMale(napis[i])) == true && (!CzySpolgloska(naMale(napis[i + 1]))) == true)
                {
                    licznik++;
                }
            }
            return licznik;
        }
        static void Main(string[] args)
        {
            int[] tablica = { 1, 2, 3, 4, 3, 4 };
            uint[] tablica2 = { 1, 2, 3, 7, 6, 4 };
            Console.WriteLine(ZnajdzMax(tablica));
            Console.WriteLine(A1(tablica));
            Console.WriteLine(A2(tablica2, 0));
            Console.WriteLine(A3("e;E;ee!"));
            Console.WriteLine("Hello World!");
        }
    }
}
