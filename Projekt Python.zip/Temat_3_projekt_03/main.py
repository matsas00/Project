import sys

from bucket_sort import bucket_sort
from solar_system_object import SolarSystemObject
from solar_system_operations import SolarSystemOperations
from solar_system_service import SolarSystemService


def launch():
    solarSystemService = SolarSystemService(SolarSystemOperations())
    solarSystemService.add_solar_object(SolarSystemObject('Merkury', 330.2*10**21, 57909170, 87.969))
    solarSystemService.add_solar_object(SolarSystemObject('Wenus', 4868.5*10**21, 108208926, 224.701))
    solarSystemService.add_solar_object(SolarSystemObject('Ziemia', 5974.2*10**21, 149597887, 365.256))
    solarSystemService.add_solar_object(SolarSystemObject('Mars', 641.9*10**21, 227936637, 686.960))
    solarSystemService.add_solar_object(SolarSystemObject('Jowisz', 1898600.8*10**21, 778412027, 4333.287))
    solarSystemService.add_solar_object(SolarSystemObject('Saturn', 568516.8*10**21, 1426725413, 10756.200))
    solarSystemService.add_solar_object(SolarSystemObject('Uran', 86841*10**21, 2870972220, 30707.490))
    solarSystemService.add_solar_object(SolarSystemObject('Neptun', 102439.6*10**21, 4498252900, 60223.353))
    while True:
        print("1. Dodawanie obiektu")
        print("2. Edycja obiektu")
        print("3. Usuwanie obiektu")
        print("4. Sortowanie obiektów")
        try:
            choice = int(input("\nWybrany numer: "))
            if (choice > 4 or choice < 1):
                raise ValueError
        except ValueError:
            print("\nNależy podać liczbę 1, 2, 3 lub 4\n")
            continue
        sol = SolarSystemObject()
        if choice == 1:
            try:
                solar_object_list = solarSystemService.get_solar_object_list()
                sol.name = str(input("\nPodaj nazwe obiektu: "))
                if sol.name.isalnum() == False: raise ValueError
                i = 0
                for object in solar_object_list:
                    if object.name == sol.name: i = i + 1
                if i>0: print("\nTaki obiekt już istnieje.\n")
                else:
                    sol.mass = float(input("Podaj mase obiektu (kg): "))
                    if sol.mass > sys.float_info.max:
                        print("Zbyt duża liczba")
                        raise ValueError
                    elif sol.mass < 0: raise ValueError
                    sol.sun_distance = float(input("Podaj odleglosc od slonca obiektu (km): "))
                    if sol.sun_distance > sys.float_info.max:
                        print("Zbyt duża liczba")
                        raise ValueError
                    elif sol.sun_distance < 0: raise ValueError
                    sol.sun_rounding = float(input("Podaj okres obiegu wokol slonca obiektu (dni): "))
                    if sol.sun_rounding > sys.float_info.max:
                        print("Zbyt duża liczba")
                        raise ValueError
                    elif sol.sun_rounding < 0: raise ValueError
                    solarSystemService.add_solar_object(sol)
                    print()
            except ValueError:
                print("\nPodano nieprawidłową wartość.\n")
                continue
        elif choice == 2:
            solar_object_list = solarSystemService.get_solar_object_list()
            print()
            for object in solar_object_list:
                print(object)
            print("\nPodaj nazwe dla której obiekt ma zmienic wartosci\n")
            name = str(input())
            print()
            i = 0
            try:
                for object in solar_object_list:
                    if object.name == name:
                        i = i + 1
                        try:
                            new_name = str(input("Podaj nowa nazwe: "))
                            if sol.name.isalnum() == False: raise ValueError
                            new_mass = float(input("Podaj nowa mase (kg): "))
                            if new_mass > sys.float_info.max:
                                print("Zbyt duża liczba")
                                raise ValueError
                            new_sun_dist = float(input("Podaj nowa odleglosc od slonca (km): "))
                            if new_sun_dist > sys.float_info.max:
                                print("Zbyt duża liczba")
                                raise ValueError
                            new_sun_rounding = float(input("Podaj nowy okres obiegu od slonca (dni): "))
                            if new_sun_rounding > sys.float_info.max:
                                print("Zbyt duża liczba")
                                raise ValueError
                            print()
                        except ValueError:
                            print('Podano nieprawidłową wartość. Edycja obiektu wstrzymana')
                            continue
                        # Jeśli nie wyrzuci błędu
                        object.name = new_name
                        object.mass = new_mass
                        object.sun_rounding = new_sun_rounding
                        object.sun_distance = new_sun_dist
                if i == 0:
                    raise ValueError
            except ValueError:
                print("Object not found\n")
                continue
        elif choice == 3:
            solar_object_list = solarSystemService.get_solar_object_list()
            print()
            for object in solar_object_list:
                print(object)
            print("\nPodaj nazwe obiektu ktory chcesz usunac\n")
            solar_system_object_name = str(input())
            solarSystemService.delete_solar_object(solar_system_object_name)
        elif choice == 4:
            print("\nm. Malejąco")
            print("r. Rosnąco\n")
            order = str(input())
            if not (order == 'm' or order == 'r'):
                print("\nPodano zły porządek sortowania\n")
                continue
            print("\n1. Sortowanie po masie")
            print("2. Sortowanie po odległości")
            print("3. Sortowanie po okresie obiegu\n")
            try:
                property_num = int(input())
                list_to_sort = solarSystemService.get_solar_object_list()
                if property_num == 1:
                    sorted_list = bucket_sort(list_to_sort, 'mass', order)
                elif property_num == 2:
                    sorted_list = bucket_sort(list_to_sort, 'sun_distance', order)
                elif property_num == 3:
                    sorted_list = bucket_sort(list_to_sort, 'sun_rounding', order)
                else:
                    raise ValueError
                print("\nPosortowana lista:")
                for i in range(len(sorted_list)):
                    print(sorted_list[i])
                print()
            except ValueError:
                print("\nPodano zły porządek sortowania\n")
                continue



if __name__ == '__main__':
    launch()

