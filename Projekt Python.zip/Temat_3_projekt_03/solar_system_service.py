from solar_system_object import SolarSystemObject
from solar_system_operations import SolarSystemOperations


class SolarSystemService:
    __solar_system_operations: SolarSystemOperations

    def __init__(self, operations):
        self.__solar_system_operations = operations

    def add_solar_object(self, object):
        self.__solar_system_operations.add_solar_system_object(object)

    def get_solar_object_list(self) -> list[SolarSystemObject]:
        return self.__solar_system_operations.get_solar_object_list()

    def delete_solar_object(self, name: str):
        self.__solar_system_operations.delete_solar_system_object(name)