from solar_system_object import SolarSystemObject


class SolarSystemOperations:
    __solarSystemObjectList: list[SolarSystemObject]

    def __init__(self):
        self.__solarSystemObjectList = []

    def add_solar_system_object(self, solar_system_object: SolarSystemObject):
        self.__solarSystemObjectList.append(solar_system_object)

    def get_solar_object_list(self):
        return self.__solarSystemObjectList

    def delete_solar_system_object(self, name: str):
        possibilities = []
        for i in range(0, len(self.__solarSystemObjectList)):
            if(self.__solarSystemObjectList[i].name == name):
                possibilities.append(i)
        if len(possibilities) == 0:
            print("\nObject not found\n")
        else:
            for poss in possibilities:
                self.__solarSystemObjectList.pop(poss)