class SolarSystemObject:
    name: str
    mass: float
    sun_distance: float
    sun_rounding: float

    def __init__(self, name = 'unnamed', mass = 0, dist = 0, sround = 0):
        self.name = name
        self.mass = mass
        self.sun_distance = dist
        self.sun_rounding = sround

    def __repr__(self):
        return f'({self.name}, {self.mass}, {self.sun_distance}, {self.sun_rounding})'
