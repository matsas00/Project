from solar_system_object import SolarSystemObject


def get_comaper_func(order: str):
    if order == 'm':
        return lambda a, b: a > b
    elif order == 'r':
        return lambda a, b: a < b

def insertion_sort(bucket, propname: str, compare_function):
    for i in range (1, len (bucket)):
        var = bucket[i]
        j = i - 1
        while j >= 0 and compare_function(getattr(var, propname), getattr(bucket[j], propname)):
            bucket[j + 1] = bucket[j]
            j = j - 1
        bucket[j + 1] = var

def bucket_sort(input_list: list[SolarSystemObject], propname: str, order: str) -> list[SolarSystemObject]:
    # if list is empty, dont sort
    if len(input_list) == 0:
        return []

    # get comp function
    compare_function = get_comaper_func(order)

    # Find maximum value in the list and use length of the list to determine which value in the list goes into which bucket
    max_value = max(map(lambda obj: getattr(obj, propname), input_list))

    size = max_value / len(input_list)

    # Create n empty buckets where n is equal to the length of the input list
    buckets_list = []
    for x in range(len(input_list)):
        buckets_list.append([])

    # Put list elements into different buckets based on the size
    for i in range(len(input_list)):
        j = int(getattr(input_list[i], propname) / size)
        if j != len(input_list):
            buckets_list[j].append(input_list[i])
        else:
            buckets_list[len(input_list) - 1].append(input_list[i])

    # Sort elements within the buckets using Insertion Sort
    for z in range(len(input_list)):
        insertion_sort(buckets_list[z], propname, compare_function)

    # Concatenate buckets with sorted elements into a single list
    final_output = []
    calc_range = range(len(input_list)) if order == 'r' else range(len(input_list) - 1, -1, -1)
    for x in calc_range:
        final_output = final_output + buckets_list[x]
    return final_output
