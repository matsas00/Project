﻿using System;

namespace Sprawdzian
{
    class Employee : IPayable
    {
        private string name;
        private int years;
        public Employee(string name)
        {
            this.name = name;
            this.years = 1;
        }
        public void Modify(string name, int years)
        {
            Console.WriteLine("Imie aktualne: " + this.name );
            Console.WriteLine("lata aktualne: " + this.years);
            this.name = name;
            this.years = years;
            Console.WriteLine("Imie zmienione: " + name);
            Console.WriteLine("Lata zmienione: " + years);
            
        }

        public virtual double CalculatePayment(double salary)
        {
            
            return salary * 0.8;
        }

        public virtual bool IsPayable()
        {
            if (years >= 10)
            {
                return true;
            }
            return false;
        }
        public override string ToString()
        {
            return $"{name} {years}";
        }
    }

    internal interface IPayable
    {
        bool IsPayable();
        double CalculatePayment(double salary);
    }

    class Manager : Employee
    {
        private int level;

        public Manager(string name, int level) : base(name)
        {  
            this.level = 1;
        }
        public int Level
        {
            set
            {
                Console.WriteLine("aktualny level: " + level);
                level = value;
                Console.WriteLine("nowy ustawiony level: " + level);
            }
        }
        public override string ToString()
        {
            return $"{base.ToString()} {level}";
        }
        public override bool IsPayable()
        {
            if (base.IsPayable() == true && level > 1)
            {
                return true;
            }
            return false;
        }
        public override double CalculatePayment(double salary)
        {
            return salary * 1.2;
        }
    }
    class Payroll
    {
        private Employee[] employess;
        private double mainSalary;
        public Payroll()
        {
            employess = new Employee[0];
            mainSalary = 1000;
        }
        public void Add(Employee employee)
        {
            Array.Resize(ref employess, employess.Length + 1);
            employess[employess.Length - 1] = employee;
        }
        public int PaymentCount()
        {
            int licznikpracownikow = 0;
            for (int i = 0; i < employess.Length; i++)
            {
                if (employess[i].IsPayable())
                {
                    licznikpracownikow++;
                }
            }
            return licznikpracownikow;
        }
        public double TotalPayment()
        {
            double suma = 0;
            for (int i = 0; i < employess.Length; i++)
            {
                suma += employess[i].CalculatePayment(1000);
            }
            return suma;
        }
        public override string ToString()
        {
            return $"{employess} {mainSalary}";
        }

    }
    delegate bool CheckSalaryHandler(double salary);
    class Program
    {
        static void Main(string[] args)
        {
            Employee E1 = new Employee("Mateusz");
            Employee E2 = new Employee("matii");
            E1.Modify("Mateo", 4);
            E2.Modify("Mateoo", 50);
            Console.WriteLine(E1.CalculatePayment(1000));
            Console.WriteLine(E1.IsPayable());
            Console.WriteLine(E1.ToString());
            Manager M1 = new Manager("program", 12);
            Manager M2 = new Manager("ja", 50);
            M1.Modify("jarek", 11);
            M1.Level = 5505050;
            Console.WriteLine(M1.ToString());
            Console.WriteLine(M1.IsPayable());
            Console.WriteLine(M1.CalculatePayment(5000));
            Payroll P1 = new Payroll();
            P1.Add(E1);
            P1.Add(E2);
            P1.Add(M1);
            P1.Add(M2);
            Console.WriteLine(P1.PaymentCount());
            Console.WriteLine(P1.ToString());
            Console.WriteLine(P1.TotalPayment());
        }
    }
}
